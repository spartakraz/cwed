#include<iostream>

static int 
main_thread(void);
static int 
calc_area(int, int);
static int 
calc_perimeter(int, int);

int main(void)
{
	return main_thread();
}

static int 
main_thread(void)
{
	int w, h, area, perimeter;
	std::cout << "**CALCULATING AREA AND PERIMETER OF A RECTANGLE**";
	std::cout << "\nENTER WIDTH OF RECTANGLE = ";
	std::cin >> w;
	std::cout << "\nENTER HEIGHT OF RECTANGLE = ";
	std::cin >> h;
	area = calc_area(w, h);
	std::cout << "\nAREA OF RECTANGLE: " << area << std::endl;
	perimeter = calc_perimeter(w, h);
	std::cout << "PERIMETER OF RECTANGLE: " << perimeter << std::endl;	
	return 0;
}

static int 
calc_area(int w, int h)
{
	return w * h;
}

static int 
calc_perimeter(int w, int h)
{
	return 2 * (h + w);
}
